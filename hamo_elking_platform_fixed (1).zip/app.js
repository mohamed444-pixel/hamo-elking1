(() => {
  const $ = id => document.getElementById(id);
  $('year').textContent = new Date().getFullYear();
  let mode = 'login', client = null, user = null;
  const authModal = $('authModal'), studentModal = $('studentModal');
  const configured = window.PLATFORM_CONFIG && !window.PLATFORM_CONFIG.supabaseUrl.includes('YOUR-PROJECT') && !window.PLATFORM_CONFIG.supabaseAnonKey.includes('YOUR_SUPABASE');
  if (configured && window.supabase) {
    client = window.supabase.createClient(window.PLATFORM_CONFIG.supabaseUrl, window.PLATFORM_CONFIG.supabaseAnonKey);
    client.auth.getSession().then(({data}) => updateSession(data.session));
    client.auth.onAuthStateChange((_event, session) => updateSession(session));
  }
  function updateSession(session) {
    user = session?.user || null;
    $('userBadge').textContent = user ? user.email : '';
    $('headerLogin').classList.toggle('hide', !!user);
    $('logoutBtn').classList.toggle('hide', !user);
  }
  function openAuth(nextMode='login') { setMode(nextMode); authModal.classList.remove('hide'); $('authMessage').textContent = configured ? '' : 'الموقع جاهز للتجربة، لكن يلزم إعداد Supabase حسب ملف README لتفعيل الحسابات الحقيقية.'; }
  function closeAuth(){authModal.classList.add('hide')}
  function setMode(nextMode) { mode = nextMode; document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.mode===mode)); $('authTitle').textContent = mode==='login'?'أهلًا بيك في المنصة':'أنشئ حساب طالب'; $('authSubmit').textContent = mode==='login'?'تسجيل الدخول':'إنشاء الحساب'; $('password').autocomplete=mode==='login'?'current-password':'new-password'; }
  $('headerLogin').addEventListener('click',()=>openAuth('login'));
  ['heroSignup','bannerSignup'].forEach(id=>$(id).addEventListener('click',()=>openAuth('signup')));
  document.querySelectorAll('.courseAccess').forEach(b=>b.addEventListener('click',()=>{if(user)openStudent();else openAuth('login')}));
  $('closeModal').addEventListener('click',closeAuth);
  authModal.querySelector('[data-close]').addEventListener('click',closeAuth);
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>setMode(t.dataset.mode)));
  $('authForm').addEventListener('submit', async e=>{
    e.preventDefault(); const email=$('email').value.trim(), password=$('password').value; const msg=$('authMessage');
    if(!client){msg.textContent='لتفعيل التسجيل الحقيقي: أنشئ مشروع Supabase، ثم املأ config.js واتبع README.';return;}
    $('authSubmit').disabled=true; msg.textContent='لحظة من فضلك…';
    try {
      const result = mode==='signup' ? await client.auth.signUp({email,password}) : await client.auth.signInWithPassword({email,password});
      if(result.error) throw result.error;
      if(mode==='signup' && !result.data.session) msg.textContent='تم إنشاء الطلب. افتح بريدك لتأكيد الحساب، ثم سجّل الدخول.';
      else {msg.textContent='تم بنجاح ❤️';setTimeout(()=>{closeAuth();if(user)openStudent()},400)}
    } catch(err) { msg.textContent=err.message || 'حصل خطأ، حاول مرة أخرى.'; }
    finally {$('authSubmit').disabled=false;}
  });
  $('logoutBtn').addEventListener('click',async()=>{if(client)await client.auth.signOut();closeStudent()});
  function openStudent(){if(!user){openAuth('login');return} $('studentEmail').textContent=user.email;studentModal.classList.remove('hide')}
  function closeStudent(){studentModal.classList.add('hide')}
  $('closeStudent').addEventListener('click',closeStudent);
  studentModal.querySelector('[data-student-close]').addEventListener('click',closeStudent);
  window.addEventListener('keydown',e=>{if(e.key==='Escape'){closeAuth();closeStudent()}});
})();
