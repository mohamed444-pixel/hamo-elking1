// ضع بيانات مشروع Supabase هنا. لا تضع service_role key في هذا الملف مطلقًا.
window.PLATFORM_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
